# helpers/context.py — g.user 바인딩, 공통 컨텍스트, 에러핸들러 (의존성 제거판)
from __future__ import annotations
from flask import g, request, url_for, render_template
from sqlalchemy import func
from extensions import db
from models import Enrollment, Submission, Assignment, Message
from helpers.auth import _current_user

def register_context_hooks(app):
    @app.before_request
    def _bind_user_to_g():
        # 로그인 여부와 무관하게 현재 사용자(데모 포함)를 g.user에 바인딩
        g.user = _current_user()

    # ===== 내부 헬퍼(서비스 임포트 없이 동작) =====
    def _assignment_progress_for_user(uid: int) -> tuple[int, int, int]:
        """진행률(%), 제출완료 과제수, 전체 과제수"""
        total = db.session.scalar(
            db.select(func.count(func.distinct(Assignment.id)))
            .join(Enrollment, Enrollment.course_id == Assignment.course_id)
            .where(Enrollment.user_id == uid)
        ) or 0

        submitted = db.session.scalar(
            db.select(func.count(func.distinct(Submission.assignment_id)))
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .join(Enrollment, Enrollment.course_id == Assignment.course_id)
            .where(
                Enrollment.user_id == uid,
                Submission.user_id == uid,
                Submission.submitted_at.is_not(None),
            )
        ) or 0

        pct = int(round(100 * submitted / total)) if total else 0
        return pct, int(submitted), int(total)

    def _average_score_for_user(uid: int) -> float | None:
        """과제 점수/만점(기본 100) 퍼센트의 평균"""
        avg_pct = db.session.scalar(
            db.select(
                func.avg(
                    100.0 * Submission.score / func.nullif(func.coalesce(Assignment.total_score, 100), 0)
                )
            )
            .join(Assignment, Assignment.id == Submission.assignment_id)
            .where(Submission.user_id == uid, Submission.score.is_not(None))
        )
        return round(float(avg_pct), 1) if avg_pct is not None else None

    def _recent_activities_for_user(uid: int, limit: int = 5) -> list[Message]:
        """최근 활동: 간단히 '내가 보낸/받은 최신 메시지'로 대체"""
        return (
            db.session.query(Message)
            .filter((Message.receiver_id == uid) | (Message.sender_id == uid))
            .order_by(Message.created_at.desc())
            .limit(limit)
            .all()
        )

    @app.context_processor
    def inject_helpers():
        def active_exact(endpoint_or_path: str = "/"):
            p = request.path
            if endpoint_or_path.startswith("/"):
                return p == endpoint_or_path
            try:
                return p == url_for(endpoint_or_path)
            except Exception:
                return False

        def active_prefix(path_prefix: str):
            return request.path.startswith(path_prefix)

        def has_role(role: str) -> bool:
            u = g.get("user")
            return bool(u and (u.role or "student") == role)

        def any_role(*roles: str) -> bool:
            u = g.get("user")
            r = (u.role or "student") if u else "student"
            return r in roles

        # 사이드바 번들 계산 (예외 안전)
        def _sidebar_bundle():
            try:
                u = g.get("user")
                if not u:
                    return {"sb_stats": {"courses": 0, "completed": 0, "avg_score": None, "progress_pct": 0}, "sb_recent": []}

                uid = u.id
                course_count = db.session.query(Enrollment).filter_by(user_id=uid).count()

                # 진행률/제출수/전체수
                progress_pct, submitted_cnt, _total = _assignment_progress_for_user(uid)

                # 평균점수
                avg_score = _average_score_for_user(uid)

                # 최근 활동(메시지)
                recent = _recent_activities_for_user(uid, limit=5)

                return {
                    "sb_stats": {
                        "courses": course_count,
                        "completed": submitted_cnt,
                        "avg_score": avg_score,
                        "progress_pct": progress_pct,
                    },
                    "sb_recent": recent,
                }
            except Exception:
                return {"sb_stats": {"courses": 0, "completed": 0, "avg_score": None, "progress_pct": 0}, "sb_recent": []}

        bundle = _sidebar_bundle()

        return dict(
            active_exact=active_exact,
            active_prefix=active_prefix,
            sb_stats=bundle["sb_stats"],
            sb_recent=bundle["sb_recent"],
            has_role=has_role,
            any_role=any_role,
            current_user=g.get("user"),
        )

    @app.errorhandler(404)
    def not_found(e):
        return render_template("404.html", e=e), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("403.html", e=e), 403

    @app.errorhandler(500)
    def server_error(e):
        return render_template("500.html", e=e), 500