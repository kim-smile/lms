# blueprints/assignments/routes.py
from __future__ import annotations
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, g
from helpers.auth import login_required
from helpers.utils import _save_upload
from models import db, Course, Assignment, Submission, Enrollment
import os
from config import Config

bp = Blueprint(
    "assignments_view",
    __name__,
    url_prefix="/assignments_view",
    # ✅ template_folder 지정해도 되지만(있어도 앱 전역 templates를 함께 탐색함),
    # 옵션 A에서는 전역 templates만 쓸 거라 헷갈리면 아예 빼도 됩니다.
)

def _remain_text(due_at: datetime | None) -> str:
    if not due_at:
        return "미정"
    now = datetime.utcnow()
    delta = due_at - now
    if delta.total_seconds() <= 0:
        return "마감 지남"
    d = delta.days
    h = (delta.seconds // 3600)
    if d and h: return f"{d}일 {h}시간"
    if d:       return f"{d}일"
    m = (delta.seconds % 3600) // 60
    if h and m: return f"{h}시간 {m}분"
    if h:       return f"{h}시간"
    return f"{m}분"

@bp.get("/", endpoint="home")
@login_required
def index():
    uid = g.user.id
    a = (
        db.session.query(Assignment)
        .join(Course, Course.id == Assignment.course_id)
        .join(Enrollment, Enrollment.course_id == Course.id)
        .filter(Enrollment.user_id == uid)
        .order_by(Assignment.due_at.is_(None), Assignment.due_at.asc())
        .first()
    )
    if a:
        return redirect(url_for("assignments_view.view", aid=a.id))
    flash("등록된 과제가 없습니다.", "info")
    return redirect(url_for("courses.home"))

@bp.get("/<int:aid>", endpoint="view")
@login_required
def view(aid: int):
    uid = g.user.id
    a = db.session.get(Assignment, aid) or abort(404)
    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=a.course_id).first()
    if not ok:
        abort(403)
    sub = db.session.query(Submission).filter_by(assignment_id=aid, user_id=uid).first()
    remain = _remain_text(a.due_at)
    # ✅ 전역 templates 폴더의 assignments_view.html
    return render_template("assignments_view.html", a=a, sub=sub, remain=remain)

@bp.route("/<int:aid>/submit", methods=["GET", "POST"], endpoint="submit")
@login_required
def submit(aid: int):
    uid = g.user.id
    a = db.session.get(Assignment, aid) or abort(404)
    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=a.course_id).first()
    if not ok:
        abort(403)
    sub = db.session.query(Submission).filter_by(assignment_id=aid, user_id=uid).first()

    if request.method == "POST":
        file = request.files.get("file")
        comment = (request.form.get("comment") or "").strip()

        file_url = _save_upload(file, prefix=f"u{uid}_a{aid}") if file else None
        if file and not file_url:
            flash("허용되지 않은 파일 형식입니다.", "error")
            return redirect(url_for("assignments_view.submit", aid=aid))

        now = datetime.utcnow()
        if not sub:
            sub = Submission(assignment_id=aid, user_id=uid)
            db.session.add(sub)

        if file_url:
            sub.file_url = file_url
        if comment:
            sub.comment = comment

        sub.submitted_at = now
        sub.updated_at = now
        db.session.commit()

        flash("제출되었습니다. (지각 제출)" if (a.due_at and now > a.due_at) else "제출되었습니다.", "success")
        return redirect(url_for("assignments_view.view", aid=aid))

    remain = _remain_text(a.due_at)
    # ✅ 전역 templates 폴더의 assignments_submit.html
    return render_template("assignments_submit.html", a=a, sub=sub, remain=remain)

@bp.post("/<int:aid>/delete-file", endpoint="delete_file")
@login_required
def delete_file(aid: int):
    uid = g.user.id
    a = db.session.get(Assignment, aid) or abort(404)

    ok = (
        db.session.query(Enrollment.id)
        .filter(Enrollment.user_id == uid, Enrollment.course_id == a.course_id)
        .first()
    )
    if not ok:
        abort(403)

    sub = (
        db.session.query(Submission)
        .filter(Submission.assignment_id == aid, Submission.user_id == uid)
        .first()
    )
    if not sub or not sub.file_url:
        flash("삭제할 파일이 없습니다.", "error")
        return redirect(url_for("assignments_view.view", aid=aid))

    # 실제 파일 삭제 (정적 업로드 경로인 경우만)
    try:
        web = sub.file_url
        if web.startswith("/static/uploads"):
            rel = web.replace("/static/uploads", "", 1).lstrip("/")
            fpath = os.path.join(Config.UPLOAD_DIR, rel)
            if os.path.isfile(fpath):
                os.remove(fpath)
    except Exception:
        pass

    # 🔽 제출 상태를 '제출 전'으로 되돌림
    sub.file_url = None
    sub.submitted_at = None         # ← 핵심
    # 선택: 채점도 초기화하고 싶다면 아래 한 줄도
    # sub.score = None
    sub.updated_at = datetime.utcnow()
    db.session.commit()

    flash("첨부파일을 삭제했습니다. (제출 전 상태로 변경)", "success")
    return redirect(url_for("assignments_view.view", aid=aid))
