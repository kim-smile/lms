# blueprints/discussion/routes.py
from __future__ import annotations
from collections import defaultdict
from flask import Blueprint, render_template, request, redirect, url_for, abort, flash, g
from sqlalchemy import func
from sqlalchemy.orm import joinedload  # ✅ 추가
from helpers.auth import login_required
from models import (
    db,
    Course,
    Enrollment,
    DiscussionThread,
    DiscussionComment,
    User,  # ✅ 추가
)

bp = Blueprint("discussion", __name__, url_prefix="/discussion")


def _ensure_enrolled(uid: int, course_id: int):
    ok = db.session.query(Enrollment.id).filter_by(user_id=uid, course_id=course_id).first()
    if not ok:
        abort(403)


# 스레드 상세
@bp.get("/<int:tid>")
@login_required
def view(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    _ensure_enrolled(g.user.id, th.course_id)

    # ✅ 댓글 + 작성자(User) 정보를 한 번에 로딩 (N+1 방지)
    rows = (
        db.session.query(DiscussionComment)
        .options(joinedload(DiscussionComment.user))  # ← 중요
        .filter(DiscussionComment.thread_id == th.id)
        .order_by(DiscussionComment.created_at.asc())
        .all()
    )

    # 트리 빌드
    by_parent: dict[int | None, list[DiscussionComment]] = defaultdict(list)
    for c in rows:
        by_parent[c.parent_id].append(c)

    def build(parent_id=None):
        out = []
        for c in by_parent.get(parent_id, []):
            out.append({"c": c, "children": build(c.id)})
        return out

    tree = build(None)
    total_comments = len(rows)

    return render_template(
        "discussion_view.html",
        thread=th,
        tree=tree,
        total_comments=total_comments,
        back_url=url_for("course_detail.detail", course_id=th.course_id, tab="discussion"),
    )


# 댓글/대댓글 작성
@bp.post("/<int:tid>/comment")
@login_required
def comment(tid: int):
    th = db.session.get(DiscussionThread, tid) or abort(404)
    _ensure_enrolled(g.user.id, th.course_id)

    body = (request.form.get("body") or "").strip()
    parent_id = request.form.get("parent_id") or None
    parent_id = int(parent_id) if parent_id else None

    if not body:
        flash("내용을 입력하세요.", "error")
        return redirect(url_for("discussion.view", tid=tid) + "#write")

    if parent_id:
        p = db.session.get(DiscussionComment, parent_id)
        if not p or p.thread_id != tid:
            flash("잘못된 요청입니다.", "error")
            return redirect(url_for("discussion.view", tid=tid))

    c = DiscussionComment(thread_id=tid, user_id=g.user.id, parent_id=parent_id, body=body)
    db.session.add(c)
    db.session.commit()
    return redirect(url_for("discussion.view", tid=tid) + f"#c{c.id}")
    rows = (
        db.session.query(DiscussionComment)
        .filter(DiscussionComment.thread_id == th.id)
        .options(joinedload(DiscussionComment.user))  # 사용자 함께 로딩
        .order_by(DiscussionComment.created_at.asc())
        .all()
    )