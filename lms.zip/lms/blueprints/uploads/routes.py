 # blueprints/uploads/routes.py
from __future__ import annotations
import os
from flask import Blueprint, current_app, send_from_directory, abort, request

bp = Blueprint("uploads", __name__, url_prefix="/u")

def _safe_path(base: str, rel: str) -> tuple[str, str]:
    base_abs = os.path.abspath(base)
    rel_norm = rel.lstrip("/\\")
    abs_path = os.path.abspath(os.path.join(base_abs, rel_norm))
    # 디렉터리 탈출 방지
    if not abs_path.startswith(base_abs + os.sep) and abs_path != base_abs:
        abort(400)
    if not os.path.isfile(abs_path):
        abort(404)
    return os.path.dirname(abs_path), os.path.basename(abs_path)

@bp.get("/<path:relpath>", endpoint="file")
def file(relpath: str):
    base = current_app.config["UPLOAD_ROOT"]
    directory, filename = _safe_path(base, relpath)
    as_att = request.args.get("dl") in ("1", "true", "yes")
    return send_from_directory(directory, filename, as_attachment=as_att)

__all__ = ("bp",)
