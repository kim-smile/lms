from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, g, send_from_directory, current_app
from sqlalchemy import or_, func
from helpers.auth import login_required
from helpers.utils import save_upload
from models import db, Board, Post, Attachment, User
import os

bp = Blueprint("board", __name__, url_prefix="/board")


def _get_board(key: str) -> Board:
    b = (
        db.session.query(Board)
        .filter(Board.key == key, Board.is_active == True)
        .first()
    )
    if not b:
        abort(404)
    return b


@bp.get("/", endpoint="home")
@login_required
def home():
    boards = (
        db.session.query(Board)
        .filter(Board.is_active == True)
        .order_by(Board.title.asc())
        .all()
    )

    latest_map: dict[int, list[tuple[Post, User]]] = {}
    counts: dict[int, int] = {}
    for b in boards:
        latest = (
            db.session.query(Post, User)
            .join(User, User.id == Post.user_id)
            .filter(Post.board_id == b.id)
            .order_by(Post.is_pinned.desc(), Post.created_at.desc())
            .limit(5)
            .all()
        )
        latest_map[b.id] = latest
        counts[b.id] = db.session.query(Post).filter(Post.board_id == b.id).count()

    return render_template("board_home.html", boards=boards, latest_map=latest_map, counts=counts)


@bp.get("/<string:key>", endpoint="list")
@login_required
def list_page(key: str):
    board = _get_board(key)
    q_raw = (request.args.get("q") or "").strip()
    q = q_raw.lower()

    qset = (
        db.session.query(Post, User)
        .join(User, User.id == Post.user_id)
        .filter(Post.board_id == board.id)
    )
    if q:
        like = f"%{q}%"
        qset = qset.filter(
            or_(
                func.lower(Post.title).like(like),
                func.lower(Post.body).like(like),
                func.lower(User.name).like(like),
            )
        )

    rows = qset.order_by(Post.is_pinned.desc(), Post.created_at.desc()).all()
    return render_template("board_list.html", board=board, rows=rows, q=q_raw)


@bp.get("/<string:key>/new", endpoint="new")
@login_required
def new_page(key: str):
    board = _get_board(key)
    if board.key == "notice" and not (g.user and g.user.role in ("instructor", "admin")):
        abort(403)
    return render_template("board_form.html", board=board)


@bp.post("/<string:key>/new", endpoint="create")
@login_required
def create(key: str):
    board = _get_board(key)
    if board.key == "notice" and not (g.user and g.user.role in ("instructor", "admin")):
        abort(403)

    title = (request.form.get("title") or "").strip()
    body = (request.form.get("body") or "").strip()
    links_raw = (request.form.get("links") or "").strip()

    if not title:
        flash("제목은 필수입니다.", "error")
        return redirect(url_for("board.new", key=board.key))

    post = Post(board_id=board.id, user_id=g.user.id, title=title, body=body)
    db.session.add(post)
    db.session.flush()  # post.id 확보

    # 링크 첨부
    if links_raw:
        for line in links_raw.splitlines():
            url = line.strip()
            if url:
                db.session.add(Attachment(post_id=post.id, kind="url", url=url))

    # 파일 첨부
    files = request.files.getlist("files")
    upload_root = current_app.config["UPLOAD_ROOT"]
    for f in files:
        if not getattr(f, "filename", ""):
            continue
        web_path = save_upload(f)  # "/static/uploads/<subdir>/<name>"
        if not web_path:
            continue
        # 저장된 상대경로(uploads 루트 기준) 계산
        rel = web_path.replace("/static/uploads/", "").lstrip("/")
        abs_path = os.path.join(upload_root, rel)
        size = os.path.getsize(abs_path) if os.path.exists(abs_path) else None
        db.session.add(
            Attachment(
                post_id=post.id,
                kind="file",
                storage_path=rel,  # DB에는 루트 기준 상대경로 저장
                original_name=getattr(f, "filename", None),
                content_type=getattr(f, "mimetype", None),
                file_size=size,
            )
        )

    db.session.commit()
    flash("게시글이 등록되었습니다.", "success")
    return redirect(url_for("board.detail", post_id=post.id))


@bp.get("/post/<int:post_id>", endpoint="detail")
@login_required
def detail(post_id: int):
    post = db.session.get(Post, post_id)
    if not post:
        abort(404)
    board = db.session.get(Board, post.board_id)

    post.views = (post.views or 0) + 1
    db.session.commit()

    author = db.session.get(User, post.user_id)
    atts = db.session.query(Attachment).filter_by(post_id=post.id).all()

    return render_template("board_detail.html", board=board, post=post, author=author, atts=atts)


@bp.get("/attach/<int:att_id>/download", endpoint="download")
@login_required
def download(att_id: int):
    a = db.session.get(Attachment, att_id)
    if not a or a.kind != "file" or not a.storage_path:
        abort(404)
    abs_dir = current_app.config["UPLOAD_ROOT"]    # <- Config 대신 현재 앱 설정
    filename = a.storage_path                      # 예: "board/2025/.../file.pdf"
    return send_from_directory(
        abs_dir,
        filename,
        as_attachment=True,
        download_name=a.original_name or os.path.basename(filename),
        mimetype=a.content_type or "application/octet-stream",
    )


@bp.post("/post/<int:post_id>/delete", endpoint="delete")
@login_required
def delete_post(post_id: int):
    post = db.session.get(Post, post_id)
    if not post:
        abort(404)

    me = g.user
    if not me or (me.id != post.user_id and me.role not in ("admin", "instructor")):
        abort(403)

    # 첨부 실제 파일 삭제
    atts = db.session.query(Attachment).filter_by(post_id=post.id).all()
    upload_root = current_app.config["UPLOAD_ROOT"]
    for a in atts:
        if a.kind == "file" and a.storage_path:
            abs_path = os.path.join(upload_root, a.storage_path)
            try:
                if os.path.exists(abs_path):
                    os.remove(abs_path)
            except Exception:
                pass

    db.session.delete(post)
    db.session.commit()
    return redirect(url_for("board.list", key=db.session.get(Board, post.board_id).key))