# services/metrics.py — 경량 순수 함수 + 선택형 JSON 라우트
from __future__ import annotations
from typing import Tuple, Optional, List, Dict, Any
from flask import Blueprint, jsonify, g
from sqlalchemy import func
from extensions import db
from models import Enrollment, Assignment, Submission, Message
from helpers.auth import login_required

def assignment_progress_for_user(uid: int) -> Tuple[int, int, int]:
    total = db.session.scalar(
        db.select(func.count(func.distinct(Assignment.id)))
        .join(Enrollment, Enrollment.course_id == Assignment.course_id)
        .where(Enrollment.user_id == uid)
    ) or 0

    submitted = db.session.scalar(
        db.select(func.count(func.distinct(Submission.assignment_id)))
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .join(Enrollment, Enrollment.course_id == Assignment.course_id)
        .where(
            Enrollment.user_id == uid,
            Submission.user_id == uid,
            Submission.submitted_at.is_not(None),
        )
    ) or 0

    pct = int(round(100 * submitted / total)) if total else 0
    return pct, int(submitted), int(total)

def average_score_for_user(uid: int) -> Optional[float]:
    avg_pct = db.session.scalar(
        db.select(
            func.avg(
                100.0 * Submission.score / func.nullif(func.coalesce(Assignment.total_score, 100), 0)
            )
        )
        .join(Assignment, Assignment.id == Submission.assignment_id)
        .where(Submission.user_id == uid, Submission.score.is_not(None))
    )
    return round(float(avg_pct), 1) if avg_pct is not None else None

def recent_activities_for_user(uid: int, limit: int = 5) -> List[Message]:
    return (
        db.session.query(Message)
        .filter((Message.receiver_id == uid) | (Message.sender_id == uid))
        .order_by(Message.created_at.desc())
        .limit(limit)
        .all()
    )

# === 선택: JSON 라우트 (프론트에서 필요할 때 호출) ===
bp = Blueprint("metrics", __name__, url_prefix="/metrics")

@bp.get("/sidebar")
@login_required
def sidebar_json():
    uid = g.user.id
    courses = db.session.query(Enrollment).filter_by(user_id=uid).count()
    progress_pct, completed_cnt, _ = assignment_progress_for_user(uid)
    avg_score = average_score_for_user(uid)
    recent = recent_activities_for_user(uid, limit=5)

    payload: Dict[str, Any] = {
        "courses": courses,
        "completed": completed_cnt,
        "progress_pct": progress_pct,
        "avg_score": avg_score,
        "recent": [
            {
                "id": m.id,
                "title": m.title,
                "from": m.sender_id,
                "to": m.receiver_id,
                "created_at": m.created_at.isoformat() if m.created_at else None,
                "read": bool(m.read_at),
            }
            for m in recent
        ],
    }
    return jsonify(payload)